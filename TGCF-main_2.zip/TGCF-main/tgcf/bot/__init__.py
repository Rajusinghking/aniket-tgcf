"""The subpackage for interative bot for tgcf."""

from .live_bot import get_events
